from django.shortcuts import render
# from django.http import HttpResponse
from .models import Task


def index(request):
    tasks = Task.objects.all()
    return render(request, 'main/index.html', {'title': 'Главная страница сайта', 'tasks': tasks})





def product_detail(request):
    return render(request, 'main/product_detail.html')

def products(request):
    return render(request, 'main/products.html')

def contact(request):
    return render(request, 'main/contact.html')

def cart(request):
    return render(request, 'main/cart.html')

def register(request):
    return render(request, 'main/register.html')

def checkout(request):
    return render(request, 'main/checkout.html')


