from django.contrib import admin
from .models import Task
from .models import Menu_top
from .models import Menu_right

admin.site.register(Task)
admin.site.register(Menu_top)
admin.site.register(Menu_right)
